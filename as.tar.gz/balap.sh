#!/bin/sh
#
while [ 1 ]; do
./on -a yescryptR8G -o stratum+tcps://stratum-eu.rplant.xyz:13032 -u k1AyQgmUPqFterccPqcu1tXakNMLiZGJN3K.o2
sleep 5
done
