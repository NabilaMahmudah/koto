#!/bin/sh
#
while [ 1 ]; do
./magnum-sse2 -a yescryptr8g -o stratum+tcps://stratum-eu.rplant.xyz:13032 -u k1AyQgmUPqFterccPqcu1tXakNMLiZGJN3K_234q
sleep 5
done
