#!/bin/bash
@echo off
 ./xmrig -a randomx --url randomx.rplant.xyz:17100 --tls --user ZEPHs8qpRw1igRzoQwesBMQRTuubopJMcEsd5LjBxdiX9zSaMDGuq4CfEeohWKu5etAXmnFuq4T7pPLJWHA4gW8K4EDAPeLduTb.zepr
